#!/bin/bash

./handler1.sh&pid1=$!
./handler2.sh&pid2=$!
