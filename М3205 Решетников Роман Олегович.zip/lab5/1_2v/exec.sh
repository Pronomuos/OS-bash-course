#!/bin/bash

./handler1.sh&pid0=$!
./handler2.sh&pid1=$!
