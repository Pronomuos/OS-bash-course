#!/bin/bash

a=0
while true;
do
	a=$a+1
done
